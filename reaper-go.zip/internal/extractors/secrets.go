package extractors

import (
	"regexp"
	"strings"
)

type Secret struct {
	Type      string
	Value     string
	KeyName   string
	Context   string
	SourceURL string
	Line      int
	Service   string
	RawLine   string
}

type secretPattern struct {
	Name    string
	Pattern *regexp.Regexp
	Group   int
	Service string
}

var secretPatterns []secretPattern

func init() {
	defs := []struct {
		name, pattern, service string
		group                  int
	}{
		// AWS
		{"AWS_ACCESS_KEY", `\b(?:AKIA|ASIA)[A-Z0-9]{16}\b`, "aws", 0},
		{"AWS_SECRET_KEY", `(?i)(?:aws_secret_access_key|aws_secret)\s*[=:]\s*['"]?([A-Za-z0-9/+=]{40})['"]?`, "aws", 1},
		{"AWS_SESSION_TOKEN", `(?i)AWS_SESSION_TOKEN\s*[=:]\s*['"]?([A-Za-z0-9/+=]{100,})['"]?`, "aws", 1},
		{"AWS_MWS_KEY", `amzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`, "aws", 0},

		// Google / GCP
		{"GOOGLE_API_KEY", `AIza[0-9A-Za-z_-]{35}`, "google", 0},
		{"GOOGLE_OAUTH", `[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com`, "google", 0},
		{"GCP_SERVICE_ACCOUNT", `"type"\s*:\s*"service_account"`, "gcp", 0},
		{"GCP_OAUTH_SECRET", `GOCSPX-[A-Za-z0-9_-]{28}`, "google", 0},

		// Azure
		{"AZURE_CLIENT_SECRET", `(?i)(?:AZURE_CLIENT_SECRET|AZURE_AD_CLIENT_SECRET)\s*[=:]\s*['"]?([A-Za-z0-9~._-]{34,})['"]?`, "azure", 1},
		{"AZURE_STORAGE_KEY", `(?i)(?:AZURE_STORAGE_KEY|AZURE_STORAGE_ACCOUNT_KEY)\s*[=:]\s*['"]?([A-Za-z0-9+/]{86}==)['"]?`, "azure", 1},
		{"AZURE_CONNECTION_STRING", `DefaultEndpointsProtocol=https?;AccountName=[^;]{3,63};AccountKey=[A-Za-z0-9+/]{86}==`, "azure", 0},

		// DigitalOcean
		{"DIGITALOCEAN_TOKEN", `\bdop_v1_[a-f0-9]{64}\b`, "digitalocean", 0},
		{"DIGITALOCEAN_REFRESH", `\bdor_v1_[a-f0-9]{64}\b`, "digitalocean", 0},

		// GitHub
		{"GITHUB_PAT", `\bgithub_pat_[A-Za-z0-9_]{36,255}\b`, "github", 0},
		{"GITHUB_OAUTH", `\bgho_[A-Za-z0-9]{36,255}\b`, "github", 0},
		{"GITHUB_USER_TOKEN", `\bghu_[A-Za-z0-9]{36,255}\b`, "github", 0},
		{"GITHUB_SERVER_TOKEN", `\bghs_[A-Za-z0-9]{36,255}\b`, "github", 0},
		{"GITHUB_REFRESH", `\bghr_[A-Za-z0-9]{36,255}\b`, "github", 0},
		{"GITHUB_CLASSIC", `\bghp_[A-Za-z0-9]{36,255}\b`, "github", 0},

		// GitLab
		{"GITLAB_PAT", `\bglpat-[A-Za-z0-9_-]{20,}\b`, "gitlab", 0},
		{"GITLAB_PIPELINE", `\bglptt-[A-Za-z0-9_-]{20,}\b`, "gitlab", 0},
		{"GITLAB_RUNNER", `\bGR1348941[A-Za-z0-9_-]{20,}\b`, "gitlab", 0},

		// Slack
		{"SLACK_BOT_TOKEN", `\bxoxb-[A-Za-z0-9-]{10,}\b`, "slack", 0},
		{"SLACK_USER_TOKEN", `\bxoxp-[A-Za-z0-9-]{10,}\b`, "slack", 0},
		{"SLACK_APP_TOKEN", `\bxapp-[A-Za-z0-9-]{10,}\b`, "slack", 0},
		{"SLACK_WEBHOOK", `https://hooks\.slack\.com/services/T[A-Za-z0-9]+/B[A-Za-z0-9]+/[A-Za-z0-9]+`, "slack", 0},

		// Discord
		{"DISCORD_BOT_TOKEN", `[MN][A-Za-z\d]{23,}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,}`, "discord", 0},
		{"DISCORD_WEBHOOK", `https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_-]+`, "discord", 0},

		// Telegram
		{"TELEGRAM_BOT_TOKEN", `\b\d{8,12}:AA[A-Za-z0-9_-]{33,35}\b`, "telegram", 0},

		// Stripe
		{"STRIPE_SECRET_KEY", `\bsk_live_[A-Za-z0-9]{24,}\b`, "stripe", 0},
		{"STRIPE_PUBLISHABLE_KEY", `\bpk_live_[A-Za-z0-9]{24,}\b`, "stripe", 0},
		{"STRIPE_RESTRICTED_KEY", `\brk_live_[A-Za-z0-9]{24,}\b`, "stripe", 0},
		{"STRIPE_WEBHOOK_SECRET", `\bwhsec_[A-Za-z0-9]{32,}\b`, "stripe", 0},
		{"STRIPE_TEST_SECRET", `\bsk_test_[A-Za-z0-9]{24,}\b`, "stripe", 0},
		{"STRIPE_TEST_PUB", `\bpk_test_[A-Za-z0-9]{24,}\b`, "stripe", 0},

		// PayPal
		{"PAYPAL_CLIENT_ID", `(?i)PAYPAL_CLIENT_ID\s*[=:]\s*['"]?(A[A-Za-z0-9_-]{60,80})['"]?`, "paypal", 1},
		{"PAYPAL_SECRET", `(?i)(?:PAYPAL_SECRET|PAYPAL_CLIENT_SECRET)\s*[=:]\s*['"]?(E[A-Za-z0-9_-]{60,80})['"]?`, "paypal", 1},

		// Square
		{"SQUARE_ACCESS_TOKEN", `\bsq0atp-[A-Za-z0-9_-]{22}\b`, "square", 0},
		{"SQUARE_OAUTH_SECRET", `\bsq0csp-[A-Za-z0-9_-]{43}\b`, "square", 0},

		// Twilio
		{"TWILIO_ACCOUNT_SID", `\bAC[0-9a-f]{32}\b`, "twilio", 0},
		{"TWILIO_AUTH_TOKEN", `(?i)(?:TWILIO_AUTH_TOKEN|TWILIO_TOKEN)\s*[=:]\s*['"]?([a-f0-9]{32})['"]?`, "twilio", 1},

		// SendGrid
		{"SENDGRID_KEY", `\bSG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\b`, "sendgrid", 0},

		// Mailgun
		{"MAILGUN_KEY", `\bkey-[a-f0-9]{32}\b`, "mailgun", 0},

		// Mailchimp
		{"MAILCHIMP_KEY", `\b[a-f0-9]{32}-us\d{1,2}\b`, "mailchimp", 0},

		// OpenAI
		{"OPENAI_KEY", `\bsk-[A-Za-z0-9]{20,}T3BlbkFJ[A-Za-z0-9]{20,}\b`, "openai", 0},
		{"OPENAI_KEY_V2", `\bsk-proj-[A-Za-z0-9_-]{40,}\b`, "openai", 0},

		// Anthropic
		{"ANTHROPIC_KEY", `\bsk-ant-api[0-9]{2}-[A-Za-z0-9_-]{30,}\b`, "anthropic", 0},

		// Grok / xAI
		{"GROK_KEY", `\bxai-[A-Za-z0-9_-]{30,}\b`, "grok", 0},

		// HuggingFace
		{"HUGGINGFACE_TOKEN", `\bhf_[A-Za-z0-9]{20,}\b`, "huggingface", 0},

		// Replicate
		{"REPLICATE_TOKEN", `\br8_[A-Za-z0-9]{36,}\b`, "replicate", 0},

		// Shopify
		{"SHOPIFY_ACCESS_TOKEN", `shpat_[A-Za-z0-9]{32}`, "shopify", 0},
		{"SHOPIFY_PRIVATE_APP", `shpca_[A-Za-z0-9]{32}`, "shopify", 0},
		{"SHOPIFY_CUSTOM_APP", `shpcb_[A-Za-z0-9]{32}`, "shopify", 0},
		{"SHOPIFY_SHARED_SECRET", `shpss_[A-Za-z0-9]{32}`, "shopify", 0},

		// Heroku
		{"HEROKU_API_KEY", `(?i)heroku[_-]?(?:api[_-]?)?key\s*[=:]\s*['"]?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['"]?`, "heroku", 1},

		// Firebase
		{"FIREBASE_URL", `https://[a-z0-9_-]{3,30}\.firebaseio\.com`, "firebase", 0},
		{"FIREBASE_SERVER_KEY", `(?i)(?:server[_-]?key|fcm[_-]?key)\s*[=:]\s*['"]?(AAAA[A-Za-z0-9_-]{140,300})['"]?`, "firebase", 1},

		// Cloudflare
		{"CLOUDFLARE_API_TOKEN", `(?i)(?:CF_API_TOKEN|CLOUDFLARE_API_TOKEN)\s*[=:]\s*['"]?([A-Za-z0-9_-]{40})['"]?`, "cloudflare", 1},

		// Datadog
		{"DATADOG_API_KEY", `(?i)(?:DD_API_KEY|DATADOG_API_KEY)\s*[=:]\s*['"]?([a-f0-9]{32})['"]?`, "datadog", 1},

		// New Relic
		{"NEWRELIC_API_KEY", `\bNRAK-[A-Z0-9]{27}\b`, "newrelic", 0},

		// Sentry
		{"SENTRY_DSN", `https://[a-f0-9]{32}@(?:o\d+\.)?(?:ingest\.)?sentry\.io/\d+`, "sentry", 0},

		// Grafana
		{"GRAFANA_API_KEY", `\bglsa_[A-Za-z0-9_-]{32,}_[0-9a-f]{8}\b`, "grafana", 0},
		{"GRAFANA_CLOUD_KEY", `\bglc_[A-Za-z0-9_-]{32,}\b`, "grafana", 0},

		// Vault
		{"VAULT_TOKEN", `\bhv[sb]\.[A-Za-z0-9]{24,100}\b`, "vault", 0},

		// NPM / PyPI
		{"NPM_TOKEN", `\bnpm_[A-Za-z0-9]{36,}\b`, "npm", 0},
		{"PYPI_TOKEN", `\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{50,}\b`, "pypi", 0},

		// Mapbox
		{"MAPBOX_TOKEN", `\bpk\.[A-Za-z0-9_-]{60,}\b`, "mapbox", 0},

		// PlanetScale
		{"PLANETSCALE_TOKEN", `\bpscale_tkn_[A-Za-z0-9_-]{32,}\b`, "planetscale", 0},
		{"PLANETSCALE_PASSWORD", `\bpscale_pw_[A-Za-z0-9_-]{32,}\b`, "planetscale", 0},

		// Supabase
		{"SUPABASE_KEY", `(?i)(?:SUPABASE_KEY|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_ANON_KEY)\s*[=:]\s*['"]?(eyJ[A-Za-z0-9_-]{100,})['"]?`, "supabase", 1},

		// Private Key
		{"PRIVATE_KEY", `-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----`, "private_key", 0},

		// JWT
		{"JWT_SECRET", `(?i)(?:JWT_SECRET|JWT_KEY|JWT_PRIVATE_KEY|JWT_SECRET_KEY)\s*[=:]\s*['"]?([A-Za-z0-9_+/=.\-]{16,})['"]?`, "jwt", 1},
		{"JWT_TOKEN", `eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+`, "jwt", 0},

		// Laravel
		{"LARAVEL_APP_KEY", `(?i)APP_KEY\s*[=:]\s*['"]?(base64:[A-Za-z0-9+/=]{20,})['"]?`, "laravel", 1},

		// Django
		{"DJANGO_SECRET_KEY", `(?i)(?:DJANGO_SECRET_KEY|SECRET_KEY)\s*[=:]\s*['"]?([A-Za-z0-9!@#$%^&*()\-_=+]{50,})['"]?`, "django", 1},

		// Database URLs
		{"DATABASE_URL", `(?i)(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|rediss?|amqps?)://[^\s'"<>]{10,}`, "database", 0},
		{"DB_PASSWORD", `(?i)(?:DB_PASS(?:WORD)?|DATABASE_PASS(?:WORD)?|MYSQL_PASSWORD|POSTGRES_PASSWORD|MYSQL_ROOT_PASSWORD)\s*[=:]\s*['"]?([^\s'"#;]{4,})['"]?`, "database", 1},

		// SMTP
		{"SMTP_URL", `smtps?://[^\s<>"']+`, "smtp", 0},
		{"SMTP_HOST", `(?i)(?:SMTP|MAIL)[_\s]*(?:HOST|SERVER)\s*[=:]\s*['"]?([^\s'"]{4,})['"]?`, "smtp", 1},
		{"SMTP_USER", `(?i)(?:SMTP|MAIL)[_\s]*(?:USER(?:NAME)?)\s*[=:]\s*['"]?([^\s'"]{3,})['"]?`, "smtp", 1},
		{"SMTP_PASS", `(?i)(?:SMTP|MAIL)[_\s]*(?:PASS(?:WORD)?)\s*[=:]\s*['"]?([^\s'"]{3,})['"]?`, "smtp", 1},
		{"SMTP_PORT", `(?i)(?:SMTP|MAIL)[_\s]*PORT\s*[=:]\s*['"]?(\d{2,5})['"]?`, "smtp", 1},

		// Basic Auth / Bearer — NOT generic, specific service detection via value
		{"BASIC_AUTH", `(?i)Basic\s+([A-Za-z0-9+/]{20,}=*)`, "auth", 1},
		{"BEARER_TOKEN", `(?i)Bearer\s+([A-Za-z0-9_\-.]{20,}={0,2})`, "auth", 1},
	}

	for _, d := range defs {
		re, err := regexp.Compile(d.pattern)
		if err != nil {
			continue
		}
		secretPatterns = append(secretPatterns, secretPattern{
			Name: d.name, Pattern: re, Group: d.group, Service: d.service,
		})
	}
}

var servicePrefixes = []struct {
	Prefix, Service string
}{
	{"sk_live_", "stripe"}, {"pk_live_", "stripe"}, {"rk_live_", "stripe"},
	{"sk_test_", "stripe"}, {"pk_test_", "stripe"}, {"whsec_", "stripe"},
	{"sk-ant-", "anthropic"}, {"sk-proj-", "openai"},
	{"xai-", "grok"}, {"hf_", "huggingface"}, {"r8_", "replicate"},
	{"ghp_", "github"}, {"gho_", "github"}, {"ghu_", "github"},
	{"ghs_", "github"}, {"ghr_", "github"}, {"github_pat_", "github"},
	{"glpat-", "gitlab"}, {"glptt-", "gitlab"},
	{"xoxb-", "slack"}, {"xoxp-", "slack"}, {"xapp-", "slack"},
	{"AKIA", "aws"}, {"ASIA", "aws"},
	{"SG.", "sendgrid"}, {"key-", "mailgun"},
	{"AC", "twilio"},
	{"shpat_", "shopify"}, {"shpca_", "shopify"},
	{"dop_v1_", "digitalocean"}, {"dor_v1_", "digitalocean"},
	{"npm_", "npm"}, {"pypi-", "pypi"},
	{"AIza", "google"}, {"GOCSPX-", "google"},
	{"hvs.", "vault"}, {"hvb.", "vault"},
	{"glsa_", "grafana"}, {"glc_", "grafana"},
	{"NRAK-", "newrelic"},
	{"pscale_tkn_", "planetscale"}, {"pscale_pw_", "planetscale"},
	{"sq0atp-", "square"}, {"sq0csp-", "square"},
	{"base64:", "laravel"},
	{"postgres://", "database"}, {"postgresql://", "database"},
	{"mysql://", "database"}, {"mongodb://", "database"},
	{"mongodb+srv://", "database"}, {"redis://", "database"},
	{"rediss://", "database"}, {"amqp://", "database"},
	{"smtp://", "smtp"}, {"smtps://", "smtp"},
}

func DetectServiceFromValue(value string) string {
	for _, sp := range servicePrefixes {
		if strings.HasPrefix(value, sp.Prefix) {
			return sp.Service
		}
	}
	if strings.HasPrefix(value, "sk-") && len(value) > 30 &&
		!strings.HasPrefix(value, "sk-ant-") &&
		!strings.HasPrefix(value, "sk-proj-") {
		return "openai"
	}
	return ""
}

var fpWords = []string{
	"example", "test", "dummy", "placeholder", "changeme",
	"xxx", "yyy", "zzz", "todo", "fixme", "insert", "replace",
	"0000000000", "1111111111", "abcdef", "123456",
	"undefined", "null", "none", "sample", "default",
}

func isFalsePositive(value string) bool {
	if len(value) < 6 {
		return true
	}
	lower := strings.ToLower(strings.Trim(value, "\"' "))
	for _, fp := range fpWords {
		if strings.Contains(lower, fp) {
			return true
		}
	}
	unique := make(map[rune]bool)
	for _, r := range value {
		unique[r] = true
	}
	if len(unique) < 3 {
		return true
	}
	if strings.HasPrefix(value, "$") || strings.HasPrefix(value, "%") ||
		strings.Contains(value, "${") || strings.Contains(value, "{{") {
		return true
	}
	return false
}

func ExtractSecrets(text, sourceURL string) []Secret {
	var results []Secret
	seen := make(map[string]bool)
	lines := strings.Split(text, "\n")

	for lineNo, line := range lines {
		for _, sp := range secretPatterns {
			for _, loc := range sp.Pattern.FindAllStringSubmatchIndex(line, -1) {
				var value string
				if sp.Group > 0 && len(loc) > sp.Group*2+1 {
					start := loc[sp.Group*2]
					end := loc[sp.Group*2+1]
					if start >= 0 && end >= 0 {
						value = line[start:end]
					}
				}
				if value == "" {
					value = line[loc[0]:loc[1]]
				}
				if value == "" || isFalsePositive(value) {
					continue
				}

				dedupKey := sp.Name + ":" + value
				if seen[dedupKey] {
					continue
				}
				seen[dedupKey] = true

				service := sp.Service
				if service == "auth" || service == "" {
					if detected := DetectServiceFromValue(value); detected != "" {
						service = detected
					} else {
						service = sp.Service
					}
				}

				ctxStart := loc[0] - 50
				if ctxStart < 0 {
					ctxStart = 0
				}
				ctxEnd := loc[1] + 50
				if ctxEnd > len(line) {
					ctxEnd = len(line)
				}

				results = append(results, Secret{
					Type:      sp.Name,
					Value:     value,
					Context:   strings.TrimSpace(line[ctxStart:ctxEnd]),
					SourceURL: sourceURL,
					Line:      lineNo + 1,
					Service:   service,
					RawLine:   strings.TrimSpace(line),
				})
			}
		}
	}
	return results
}

func ExtractEnvPairs(text, sourceURL string) []Secret {
	envRe := regexp.MustCompile(`^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$`)
	var results []Secret
	for lineNo, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		m := envRe.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		key := m[1]
		val := strings.Trim(strings.TrimSpace(m[2]), "\"'")
		if val == "" {
			continue
		}
		service := DetectServiceFromValue(val)
		if service == "" {
			service = detectServiceFromKey(key)
		}
		results = append(results, Secret{
			Type: key, Value: val, KeyName: key,
			SourceURL: sourceURL, Line: lineNo + 1,
			Service: service, RawLine: line,
		})
	}
	return results
}

func detectServiceFromKey(key string) string {
	upper := strings.ToUpper(key)
	m := []struct {
		pfx []string
		svc string
	}{
		{[]string{"AWS_", "AMAZON_"}, "aws"},
		{[]string{"OPENAI"}, "openai"},
		{[]string{"ANTHROPIC"}, "anthropic"},
		{[]string{"STRIPE"}, "stripe"},
		{[]string{"SENDGRID", "SG_"}, "sendgrid"},
		{[]string{"MAILGUN", "MG_"}, "mailgun"},
		{[]string{"TWILIO"}, "twilio"},
		{[]string{"GITHUB"}, "github"},
		{[]string{"GITLAB"}, "gitlab"},
		{[]string{"SLACK"}, "slack"},
		{[]string{"DISCORD"}, "discord"},
		{[]string{"TELEGRAM"}, "telegram"},
		{[]string{"SMTP_", "MAIL_"}, "smtp"},
		{[]string{"DB_", "DATABASE_", "MYSQL_", "POSTGRES_", "MONGO_", "REDIS_"}, "database"},
		{[]string{"FIREBASE"}, "firebase"},
		{[]string{"CLOUDFLARE", "CF_"}, "cloudflare"},
		{[]string{"HEROKU"}, "heroku"},
		{[]string{"SHOPIFY"}, "shopify"},
		{[]string{"PAYPAL"}, "paypal"},
		{[]string{"DATADOG", "DD_"}, "datadog"},
		{[]string{"SENTRY"}, "sentry"},
		{[]string{"VERCEL"}, "vercel"},
		{[]string{"NETLIFY"}, "netlify"},
		{[]string{"DIGITAL_OCEAN", "DO_", "SPACES_"}, "digitalocean"},
		{[]string{"HETZNER", "HCLOUD"}, "hetzner"},
		{[]string{"SUPABASE"}, "supabase"},
		{[]string{"AUTH0"}, "auth0"},
		{[]string{"OKTA"}, "okta"},
		{[]string{"JWT"}, "jwt"},
		{[]string{"LARAVEL", "APP_KEY"}, "laravel"},
		{[]string{"DJANGO"}, "django"},
		{[]string{"GOOGLE_", "GCP_"}, "google"},
		{[]string{"AZURE_"}, "azure"},
	}
	for _, km := range m {
		for _, p := range km.pfx {
			if strings.Contains(upper, p) {
				return km.svc
			}
		}
	}
	return ""
}